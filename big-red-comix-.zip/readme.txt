﻿=== Comix Big Red Cursor Set ===

By: Helios

Download: http://www.rw-designer.com/cursor-set/big-red-comix-

Author's decription:

Windows port of the Big Red Comix cursor theme by Jens Luetkens from KDE-Look.org, made especially for people with worse vision.

Enjoy! 

==========

License: Creative Commons - Attribution + Share Alike

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
* Share Alike - If you alter, transform, or build upon this work,
  you may distribute the resulting work only under the same, similar
  or a compatible license.